#!/bin/zsh

dpkg-deb -b ./apt-appapt
dpkg-deb --contents ./arm64